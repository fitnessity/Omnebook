<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductColors extends Model
{
  
	protected $table='product_colors';
	protected $guarded = [];  

}